﻿using Microsoft.EntityFrameworkCore;
using UniversityDB.Models.DataModels;

namespace UniversityDB.DataAccess
{
    public class UniversityDBContext : DbContext
    {
        public UniversityDBContext(DbContextOptions<UniversityDBContext> optionts) : base(optionts)
        {

        }

        // TODO: agregar db sets tabla de nuestra tabla
        public DbSet<Curso>? Cursos { get; set; }

    }
}
